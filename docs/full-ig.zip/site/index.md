<a name="intro"> </a>
### Introduction

What is this IG about (in patient/non-expert friendly terms).