package http://hl7.org/cda/us/ccda;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class PatientReferralAct {

}
