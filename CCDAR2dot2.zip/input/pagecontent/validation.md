[Previous Page - Appendix](appendix.html)

TODO: This page should describe how to validate a CDA document using FHIR tooling (ex: the FHIR validator tool)

[Next Page - Downloads](downloads.html)